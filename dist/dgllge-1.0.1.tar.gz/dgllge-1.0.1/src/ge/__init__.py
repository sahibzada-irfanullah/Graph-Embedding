from .utils import *
from .skipgram import *
from .deepWalk import DeepWalk
from .node2vec import Node2vec
from .struc2vec import Struc2Vec

__version__ = "1.0.1"